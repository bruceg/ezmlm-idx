#ifndef AUTO_BIN_H
#define AUTO_BIN_H

extern char auto_bin[];

#endif
