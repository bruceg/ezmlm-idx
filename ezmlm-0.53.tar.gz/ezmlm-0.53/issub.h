#ifndef ISSUB_H
#define ISSUB_H

#include "strerr.h"

extern struct strerr issub_err;

extern int issub();

#endif
