#ifndef SLURP_H
#define SLURP_H

extern int slurp();

#endif
