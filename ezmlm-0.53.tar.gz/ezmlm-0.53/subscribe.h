#ifndef SUBSCRIBE_H
#define SUBSCRIBE_H

#include "strerr.h"

extern struct strerr subscribe_err;

extern int subscribe();

#endif
