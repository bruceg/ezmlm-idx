#ifndef COOKIE_H
#define COOKIE_H

#define COOKIE 20

extern void cookie();

#endif
