#ifndef DATE822FMT_H
#define DATE822FMT_H

extern unsigned int date822fmt();
#define DATE822FMT 60

#endif
