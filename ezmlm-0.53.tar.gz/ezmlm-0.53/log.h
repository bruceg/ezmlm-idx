#ifndef LOG_H
#define LOG_H

extern void log();

#endif
