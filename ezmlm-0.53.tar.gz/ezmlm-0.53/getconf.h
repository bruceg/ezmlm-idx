#ifndef GETCONF_H
#define GETCONF_H

extern int getconf();
extern int getconf_line();

#endif
